package com.example.simplicityaclientforreddit

import com.example.simplicityaclientforreddit.ui.main.SessionDatabase
import com.example.simplicityaclientforreddit.ui.main.SessionDatabase.SessionDB
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.models.internal.Session
import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    var itemsInEachFetch = 3
    var posts = ArrayList<RedditPost>()
    var nextId: String? = ""
    var firstFetch: ArrayList<RedditPost>? = null
    var db = SessionDB(ArrayList())

    lateinit var currentSession: Session

    private fun setUp() {
        for(i in 1..20){
            posts.add(generatePost())
        }
        firstFetch = fetchPosts()

        nextId = try {
            posts[itemsInEachFetch].data.id
        } catch (e: Exception) {
            null
        }
        currentSession = Session(SessionDatabase().getSessionId(), firstFetch?.first()?.data?.id, null, nextId, 0, null)
        db.sessions.add(currentSession)
        db.sessions.add(Session(SessionDatabase().getSessionId(), posts[8].data.id, null, posts[9].data.id, 0, null))
        db.sessions.add(Session(SessionDatabase().getSessionId(), posts[13].data.id, null, posts[14].data.id, 0, null))
    }

    @Test
    fun sessionTest() {
        setUp()
        println("Got this list : $firstFetch with next id [$nextId]")
        firstFetch?.let { displayPosts(it) }
        println("-- Started application")
        while(fetchAndDisplay()){
        }
        println("No more posts to show")
    }

    private fun fetchAndDisplay(): Boolean {
        val currentFetch = fetchPosts()
        return if(currentFetch != null){
            displayPosts(currentFetch)
        }else{
            false
        }
    }

    private fun displayPosts(posts: ArrayList<RedditPost>): Boolean {
        for(post in posts){
            if(filterPostUseCase(post)){
                println("Showing post with id [${post.data.id}] position ${getPostPositionById(post.data.id)}")
            }
        }
        return true
    }

    private fun filterPostUseCase(post: RedditPost): Boolean {
        val usersLastSession = getNextSession(currentSession.id)
        if(usersLastSession == null){
            return true
        }else if(post.data.id.equals(usersLastSession.firstId)){
            currentSession = combineSessions(currentSession, usersLastSession)
            db.sessions[0] = currentSession
            db.sessions.removeAt(1)
            return false
        }
        return true
    }

    private fun combineSessions(currentSession: Session, usersLastSession: Session): Session {
        val combinedSession = Session(usersLastSession.id, currentSession.firstId, currentSession.lastReadId, usersLastSession.nextId, usersLastSession.count + currentSession.count, null)
        return combinedSession
    }

    fun getNextSession(currentSessionId: String): Session? {
        for((position, session) in db.sessions.withIndex()){
            if(session.id == currentSessionId){
                val nextSessionsPosition = position + 1
                if(db.sessions.size > nextSessionsPosition){
                    return db.sessions[nextSessionsPosition]
                }
            }
        }
        return null
    }

    // This is only for test
    private fun getPostPositionById(id: String?): Int {
        for((position, post) in posts.withIndex()){
            if(post.data.id.equals(id)){
                return position
            }
        }
        return 0
    }

    // This is replaced with network call
    private fun fetchPosts(): ArrayList<RedditPost>? {
        val i = getPostPositionById(nextId)
        if(i >= 0 && i + itemsInEachFetch < posts.size){
            nextId = posts[i + itemsInEachFetch].data.id
            return ArrayList(posts.subList(i, i + itemsInEachFetch))
        }
        return null
    }

    private fun generatePost(): RedditPost {
        return RedditPost(RedditPost.Data(id = SessionDatabase().getSessionId()))
    }
}