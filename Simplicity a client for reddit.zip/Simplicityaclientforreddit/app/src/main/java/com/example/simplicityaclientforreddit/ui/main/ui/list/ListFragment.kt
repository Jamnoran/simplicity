package com.example.simplicityaclientforreddit.ui.main.ui.list

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.simplicityaclientforreddit.MainActivity
import com.example.simplicityaclientforreddit.R
import com.example.simplicityaclientforreddit.ui.main.SessionDatabase
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.models.internal.enums.PostType
import com.example.simplicityaclientforreddit.ui.main.ui.WebViewFragment
import com.example.simplicityaclientforreddit.ui.main.ui.custom.BaseFragment
import com.example.simplicityaclientforreddit.ui.main.ui.list.adapter.RedditListAdapter
import com.example.simplicityaclientforreddit.ui.main.usecases.GetPostTypeUseCase
import java.util.*


class ListFragment : BaseFragment() {

    // 5IyfyqHZKHflfxTAKUj3zg

    companion object {
        fun newInstance() = ListFragment()
    }

    private lateinit var viewModel: ListViewModel
    private lateinit var redditListAdapter: RedditListAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.main_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(ListViewModel::class.java)
        initAdapter()
        initInput()
        viewModel.initSession()
        viewModel.fetchPosts()
        viewModel.posts().observe(requireActivity(), { observeRedditPosts(it)} )
    }

    private fun initAdapter() {
        val displayMetrics = DisplayMetrics()
        activity?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        val width = displayMetrics.widthPixels
        redditListAdapter = RedditListAdapter (width) {
            Log.i("MainFragment", "Reddit post clicked")
            handleClick(it)
        }
        view?.findViewById<RecyclerView>(R.id.recycler_view)?.let{ recyclerView ->
            recyclerView.adapter = redditListAdapter
            recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                    super.onScrollStateChanged(recyclerView, newState)
                    if (!recyclerView.canScrollVertically(1)) {
//                        Toast.makeText(context, "Loading more posts", Toast.LENGTH_LONG).show()
                        viewModel.fetchPosts()
                    }
                }
            })
        }
    }

    private fun handleClick(it: RedditPost) {
        when(GetPostTypeUseCase().execute(it.data)){
            PostType.IMGUR_LINK -> {
                it.data.url?.let{ link -> sendToBrowser(link) }
//                it.data.url?.let{ (activity as MainActivity).startWebViewActivity(it) }
                return
            }
            PostType.LINK -> {
                it.data.url?.let{ url ->
                    (activity as MainActivity).startWebViewActivity(url)
                }
                return
            }
            PostType.IMAGE -> openReddit(it)
            PostType.RICH_VIDEO -> openReddit(it)
            PostType.IS_VIDEO -> openReddit(it)
            PostType.GALLERY -> openReddit(it)
            PostType.NONE -> {
                when {
                    it.data.url != null -> {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(it.data.url))
                        startActivity(browserIntent)
                    }
                    it.data.permalink != null -> {
                        openReddit(it)
                    }
                    else -> {
                        Log.i("ListFragment", "Could not find click method for this post $it")
                    }
                }
            }
        }
    }

    private fun openReddit(it: RedditPost) {
        if(it.data.permalink != null){
            val convertedUrl = "https://www.reddit.com${it.data.permalink}"
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(convertedUrl))
            startActivity(browserIntent)
        }
    }


    private fun sendToBrowser(url: String) {
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        Log.i("ListFragment", "Sending this url to browser: $url")
        startActivity(i)

    }

    private fun initInput() {
        view?.findViewById<Button>(R.id.next)?.setOnClickListener {
//            viewModel.fetchPosts()
            (activity as MainActivity).startWebViewActivity("https://i.imgur.com/MBtV8jD.gifv")
        }
        view?.findViewById<Button>(R.id.show_sessions)?.setOnClickListener {
            var result = "Stored sessions:\n\n\n"
            for(session in SessionDatabase().getSessions()){
                result = result.plus(session).plus("\n\n")
            }
            view?.findViewById<TextView>(R.id.content)?.text = result
        }
    }


    private fun observeRedditPosts(posts: ArrayList<RedditPost>?) {
        redditListAdapter.submitList(posts?.toMutableList())
    }

}