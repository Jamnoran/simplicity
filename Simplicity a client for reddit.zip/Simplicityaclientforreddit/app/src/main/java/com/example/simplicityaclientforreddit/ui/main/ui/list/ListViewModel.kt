package com.example.simplicityaclientforreddit.ui.main.ui.list

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.simplicityaclientforreddit.ui.main.io.retrofit.APIInterface
import com.example.simplicityaclientforreddit.ui.main.io.retrofit.RetrofitClientInstance
import com.example.simplicityaclientforreddit.ui.main.models.external.JsonResponse
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.models.internal.Session
import com.example.simplicityaclientforreddit.ui.main.usecases.FilterPostsUseCase
import com.example.simplicityaclientforreddit.ui.main.usecases.CreateSessionUseCase
import com.example.simplicityaclientforreddit.ui.main.usecases.GetCurrentSessionUseCase
import com.example.simplicityaclientforreddit.ui.main.usecases.StoreSessionUseCase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ListViewModel : ViewModel() {

    private val _cachedPosts = ArrayList<RedditPost>()
    private val _redditPostsLiveData = MutableLiveData<ArrayList<RedditPost>>()
    private var _cursor: String = ""
//    private var _cursor: String = "t3_r6501w"
//    private var _cursor: String = "t3_r6s02u"
    private var _currentSession: Session? = null
    private var fetching = false

    fun posts() : MutableLiveData<ArrayList<RedditPost>>{
        return _redditPostsLiveData
    }

    fun fetchPosts() {
        if (!fetching) {
            fetchPosts(_cursor)
        }
    }

    private fun fetchPosts(cursor: String) {
        fetching = true
        Log.i("RedditRepository", "Getting reddit posts with this cursor: $cursor")
        val service = RetrofitClientInstance.getRetrofitInstance().create(
            APIInterface::class.java
        )
        val call = service.getPosts(cursor)
//        val call = service.getSluttySubRedditPosts(cursor)
        call.enqueue(object : Callback<JsonResponse> {
            override fun onResponse(
                call: Call<JsonResponse>,
                response: Response<JsonResponse>
            ) {
                var shouldFetchMore = false
                response.body()?.data?.let { data ->
                    _cursor = data.after
                    _currentSession?.nextId = _cursor
                    shouldFetchMore = processFetchedPost(data.children)

                    if (_currentSession?.firstId == null && _cachedPosts.size > 0) {
                        _currentSession?.firstId = _cachedPosts.first().data.id
                    }

                    _currentSession?.let { StoreSessionUseCase().storeSession(it) }
                }
                _redditPostsLiveData.postValue(_cachedPosts)
                Log.i("MainViewModel", "Showing [${_cachedPosts.size}] posts")
                if(shouldFetchMore){
                    // Fetching next set of posts.
                    fetchPosts(_cursor)
                }else{
                    fetching = false
                }
            }

            override fun onFailure(call: Call<JsonResponse>, t: Throwable) {
                Log.e("RedditRepository", "Error : ", t)
                fetching = false
            }
        })
    }

    private fun processFetchedPost(children: List<RedditPost>):Boolean {
        for(child in children){
            if(FilterPostsUseCase().canAdd(child)){
                _cachedPosts.add(child)
            }else{
                _cursor = GetCurrentSessionUseCase().getCurrentSession()?.nextId ?: ""
                Log.i("RedditRepository", "Combined a session, we can jump to next set of posts, setting the cursor to $_cursor.")
                _currentSession = GetCurrentSessionUseCase().getCurrentSession()
                return true
            }
        }
        return false
    }

    fun setSessionsLastReadId(readId: String){
        _currentSession?.let{
            it.lastReadId = readId
            StoreSessionUseCase().storeSession(it)
        }
    }

    fun initSession() {
        if(_currentSession == null){
            _currentSession = CreateSessionUseCase().createSession()
        }
    }

    fun fetchPost(id: String) {
        TODO("Not yet implemented")
    }
}