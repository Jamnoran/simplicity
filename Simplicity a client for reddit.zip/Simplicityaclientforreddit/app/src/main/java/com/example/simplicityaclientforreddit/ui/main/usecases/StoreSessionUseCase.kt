package com.example.simplicityaclientforreddit.ui.main.usecases

import com.example.simplicityaclientforreddit.ui.main.SessionDatabase
import com.example.simplicityaclientforreddit.ui.main.models.internal.Session


class StoreSessionUseCase {

    fun storeSession(updatedSession: Session) {
        val db = SessionDatabase()
        val sessions = db.getSessions()
        if (sessions.isNotEmpty()) {
            for(session in sessions){
                if(updatedSession.id == session.id){
                    session.firstId = updatedSession.firstId
                    session.lastReadId = updatedSession.lastReadId
                    session.count = updatedSession.count
                    session.unreadPosts = updatedSession.unreadPosts
                    session.nextId = updatedSession.nextId
//                    Log.i("StoreSessionUseCase", "Updating already existing sessions")
                }
            }
        }else{
            sessions.add(updatedSession)
        }
        db.updateSessions(sessions)
    }
}