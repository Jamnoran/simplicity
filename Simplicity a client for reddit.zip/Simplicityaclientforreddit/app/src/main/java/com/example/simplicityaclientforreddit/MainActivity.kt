package com.example.simplicityaclientforreddit

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import com.example.simplicityaclientforreddit.ui.main.Global
import com.example.simplicityaclientforreddit.ui.main.ui.custom.BaseFragment
import com.example.simplicityaclientforreddit.ui.main.ui.detail.DetailFragment
import com.example.simplicityaclientforreddit.ui.main.ui.list.ListFragment
import com.example.simplicityaclientforreddit.ui.main.ui.webview.WebViewActivity

class MainActivity : AppCompatActivity() {

    var currentFragment: BaseFragment? = null
    var previousFragment: BaseFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.main_activity)
        Global.applicationContext = applicationContext
        if (savedInstanceState == null) {
//            startFragment(ListFragment.newInstance())
            startFragment(DetailFragment.newInstance())
//            startWebViewActivity("https://i.imgur.com/MBtV8jD.gifv")
//            startWebViewActivity("https://www.redditmedia.com/mediaembed/ptnj5n")
//            startWebViewActivity("https://i.imgur.com/gK1zKGP.gifv")
//            startWebViewActivity("http://jamnoran.se/test2.html")
        }
    }

    fun startFragment(fragment: BaseFragment){
        previousFragment = currentFragment
        currentFragment = fragment
        currentFragment?.let{
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, it)
                .commitNow()
        }
    }

    fun startWebViewActivity(url: String) {
        val intent = Intent(this, WebViewActivity::class.java)
        intent.apply { putExtra("URL", url) }
        startActivity(intent)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        Log.i("MainActivity", "onKeyDown $keyCode ${event.toString()}")
        return if (keyCode == KeyEvent.KEYCODE_BACK && event.repeatCount == 0) {
            currentFragment?.let { it ->
                if(!it.onKeyDown(keyCode, event)){
                    Log.i("MainActivity", "Got back that current screen cant handle")
                    goBack(keyCode, event)
                }
            }
            true
        } else super.onKeyDown(keyCode, event)
    }

    private fun goBack() {
        previousFragment?.let{ pFrag ->
            startFragment(pFrag)
            previousFragment = null
            return
        }
        finish()
    }

    private fun goBack(keyCode: Int, event: KeyEvent) {
        previousFragment?.let{ pFrag ->
            startFragment(pFrag)
            previousFragment = null
            return
        }
        super.onKeyDown(keyCode, event)
    }
}