package com.example.simplicityaclientforreddit.ui.main.io.retrofit

import com.example.simplicityaclientforreddit.ui.main.models.external.JsonResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface APIInterface {
    @GET("r/all/.json")
    fun getPost(@Query(value = "after") after: String?): Call<JsonResponse>

    @GET("r/all/.json")
    fun getPosts(@Query(value = "after") after: String?): Call<JsonResponse>

    @GET("r/valheim/.json")
    fun getSubRedditPosts(@Query(value = "after") after: String?): Call<JsonResponse>

    @GET("r/SluttyConfessions/.json")
    fun getSluttySubRedditPosts(@Query(value = "after") after: String?): Call<JsonResponse>
}