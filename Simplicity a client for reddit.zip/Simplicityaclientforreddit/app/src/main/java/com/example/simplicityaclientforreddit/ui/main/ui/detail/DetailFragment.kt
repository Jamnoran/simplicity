package com.example.simplicityaclientforreddit.ui.main.ui.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.ViewModelProvider
import com.example.simplicityaclientforreddit.R
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.ui.custom.BaseFragment
import com.example.simplicityaclientforreddit.ui.main.ui.custom.RedditMedia
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.ui.StyledPlayerView
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.webkit.WebView
import com.example.simplicityaclientforreddit.ui.main.ui.custom.WebClientClass
import android.widget.RelativeLayout
import androidx.room.RoomDatabase
import com.example.simplicityaclientforreddit.ui.main.io.room.RoomDB


class DetailFragment : BaseFragment() {

    companion object {
        fun newInstance() = DetailFragment()
    }

    private lateinit var viewModel: DetailViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.detail_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(DetailViewModel::class.java)

//        viewModel.parsePost(resources.openRawResource(R.raw.post_raw_video2).bufferedReader().use { it.readText() })
//        viewModel.parsePost(resources.openRawResource(R.raw.post_raw_video).bufferedReader().use { it.readText() })
        viewModel.parsePost(resources.openRawResource(R.raw.post_raw_imgur).bufferedReader().use { it.readText() })
        viewModel.post().observe(requireActivity(), {
//            observeRedditPost(it)
            test(it)
        }
        )
    }

    private fun test(it: RedditPost) {
//        view?.findViewById<StyledPlayerView>(R.id.reddit_player)?.let{ playerView ->
//            showImgur(it, playerView)
//        }

//        sendToBrowser("https://i.imgur.com/gK1zKGP.gifv")

        val db = RoomDB()
        db.toReadPost(it)?.let{
            Log.i("DetailFragment","Post to save to db: $it")
            db.insertPost(it)
        }
    }

    private fun sendToBrowser(url: String) {
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        startActivity(i)
    }

    private fun observeRedditPost(post: RedditPost) {
        view?.let{
            it.findViewById<ConstraintLayout>(R.id.reddit_media)?.let { constraintLayout ->
                RedditMedia(it.width).init(post,
                    constraintLayout
                )
            }
        }
        if(post.data.postHint != "link"){
            view?.findViewById<TextView>(R.id.reddit_title)?.text = post.data.title
        }else{
            view?.findViewById<TextView>(R.id.reddit_title)?.visibility = View.GONE
        }
    }

}