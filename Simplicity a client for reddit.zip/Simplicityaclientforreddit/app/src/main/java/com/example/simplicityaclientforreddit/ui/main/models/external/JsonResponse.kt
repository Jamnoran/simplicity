package com.example.simplicityaclientforreddit.ui.main.models.external

import com.google.gson.annotations.SerializedName

class JsonResponse(
    @SerializedName("data")
    val data: Data
){
    class Data(
        @SerializedName("after")
        val after: String,
        @SerializedName("dist")
        val dist: Int,
        @SerializedName("children")
        val children: List<RedditPost>
    )
}