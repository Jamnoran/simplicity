package com.example.simplicityaclientforreddit.ui.main.usecases

import com.example.simplicityaclientforreddit.ui.main.SessionDatabase
import com.example.simplicityaclientforreddit.ui.main.models.internal.Session


class CreateSessionUseCase {
    fun createSession(): Session {
        return SessionDatabase().createSession()
    }
}