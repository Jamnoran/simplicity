package com.example.simplicityaclientforreddit.ui.main.ui.custom

import android.view.KeyEvent
import androidx.fragment.app.Fragment

open class BaseFragment: Fragment() {

    open fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return false
    }
}
