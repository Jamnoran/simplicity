package com.example.simplicityaclientforreddit.ui.main.ui.list.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.simplicityaclientforreddit.R
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.ui.custom.RedditMedia
import java.text.NumberFormat

class RedditListAdapter(private val layoutWidth: Int, private val onClick: (RedditPost) -> Unit) :
    ListAdapter<RedditPost, RedditListAdapter.PostViewHolder>(PostDiffCallback) {

    /* ViewHolder for Flower, takes in the inflated view and the onClick behavior. */
    class PostViewHolder(val width: Int,itemView: View, val onClick: (RedditPost) -> Unit) :
        RecyclerView.ViewHolder(itemView) {
        private val postTitleView: TextView = itemView.findViewById(R.id.reddit_title)
        private val postLinkSrcView: TextView = itemView.findViewById(R.id.reddit_link_src)
        private val postLinkImageView: ImageView = itemView.findViewById(R.id.reddit_link_preview)
        private val subTextView: TextView = itemView.findViewById(R.id.reddit_sub)
        private var currentPost: RedditPost? = null

        init {
//            itemView.setOnClickListener {
//                currentPost?.let {
//                    onClick(it)
//                }
//            }
            postTitleView.setOnClickListener {
                currentPost?.let {
                    onClick(it)
                }
            }
            postLinkImageView.setOnClickListener {
                currentPost?.let {
                    onClick(it)
                }
            }
            postLinkSrcView.setOnClickListener {
                currentPost?.let {
                    onClick(it)
                }
            }
        }

        /* Bind post data. */
        fun bind(post: RedditPost) {
            currentPost = post
            RedditMedia(width).init(post, itemView.findViewById(R.id.reddit_media))
            populateVoting(itemView, post)
//            debug(post, itemView)
            "r/${post.data.subreddit} posted by u/${post.data.author}".also { subTextView.text = it }

            if(post.data.postHint != "link"){
                "${post.data.title} [${post.data.postHint}]".also { postTitleView.text = it }
                postTitleView.visibility = View.VISIBLE
            }else{
                postTitleView.visibility = View.GONE
            }
        }

        private fun debug(post: RedditPost, itemView: View) {
            itemView.findViewById<TextView>(R.id.reddit_title).text = post.data.title
            itemView.findViewById<View>(R.id.reddit_media).visibility = View.GONE
        }

        private fun populateVoting(itemView: View, post: RedditPost) {
            val votes = (post.data.ups - post.data.downs)
            val formatted = NumberFormat.getInstance().format(votes)
            itemView.findViewById<TextView>(R.id.votes).text = "$formatted"
        }
    }

    /* Creates and inflates view and return FlowerViewHolder. */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.reddit_post, parent, false)
        return PostViewHolder(layoutWidth, view, onClick)
    }

    /* Gets current flower and uses it to bind view. */
    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val flower = getItem(position)
        holder.bind(flower)

    }
}

object PostDiffCallback : DiffUtil.ItemCallback<RedditPost>() {
    override fun areItemsTheSame(oldItem: RedditPost, newItem: RedditPost): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: RedditPost, newItem: RedditPost): Boolean {
        return oldItem.data.id == newItem.data.id
    }
}