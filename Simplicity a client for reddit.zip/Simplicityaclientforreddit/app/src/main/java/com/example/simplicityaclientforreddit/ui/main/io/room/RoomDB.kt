package com.example.simplicityaclientforreddit.ui.main.io.room

import androidx.room.Room
import com.example.simplicityaclientforreddit.ui.main.Global.applicationContext
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.models.internal.ReadPost
import java.util.*

class RoomDB {

//    fun getReadPost(post: ReadPost): List<ReadPost> {
//        val db = Room.databaseBuilder(
//            applicationContext,
//            AppDatabase::class.java, "simplicity_database"
//        ).build()
//        val dao = db.readPostDao()
//        return dao.loadAllByIds(intArrayOf(post.id))
//    }

    fun getReadPost(post: ReadPost): ReadPost {
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "simplicity_database"
        ).build()
        val dao = db.readPostDao()
        return dao.findByUUID(post.uuid)
    }

    fun insertPost(post: ReadPost){
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "simplicity_database"
        ).build()
        val dao = db.readPostDao()
        dao.insertAll(post)
    }

    fun toReadPost(it: RedditPost): ReadPost? {
        val currentTime = Calendar.getInstance().time
        var date = currentTime.toString()
        it.data.id?.let{ uuid ->
            it.data.url?.let{ url ->
                return ReadPost(0, uuid, url, date)
            }
        }
        return null
    }

}