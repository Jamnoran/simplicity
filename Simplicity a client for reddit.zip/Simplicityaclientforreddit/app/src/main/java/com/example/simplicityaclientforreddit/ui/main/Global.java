package com.example.simplicityaclientforreddit.ui.main;

import android.content.Context;

public class Global {
    public static Context applicationContext;
}