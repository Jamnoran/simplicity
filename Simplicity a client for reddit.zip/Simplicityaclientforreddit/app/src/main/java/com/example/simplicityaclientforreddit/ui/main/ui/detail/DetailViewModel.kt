package com.example.simplicityaclientforreddit.ui.main.ui.detail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.google.gson.Gson


class DetailViewModel : ViewModel() {

    private val _post = MutableLiveData<RedditPost>()

    fun post() : MutableLiveData<RedditPost>{
        return _post
    }

    fun parsePost(json: String) {
        _post.postValue(Gson().fromJson(json, RedditPost::class.java))
    }
}