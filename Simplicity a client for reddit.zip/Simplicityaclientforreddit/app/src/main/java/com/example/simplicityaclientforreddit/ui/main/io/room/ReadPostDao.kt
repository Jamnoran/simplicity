package com.example.simplicityaclientforreddit.ui.main.io.room

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.simplicityaclientforreddit.ui.main.models.internal.ReadPost

@Dao
interface ReadPostDao {
    @Query("SELECT * FROM ReadPost")
    fun getAll(): List<ReadPost>

    @Query("SELECT * FROM ReadPost WHERE id IN (:ReadPostIds)")
    fun loadAllByIds(ReadPostIds: IntArray): List<ReadPost>

    @Query("SELECT * FROM ReadPost WHERE url LIKE :url LIMIT 1")
    fun findByUrl(url: String): ReadPost

    @Query("SELECT * FROM ReadPost WHERE uuid LIKE :uuid LIMIT 1")
    fun findByUUID(uuid: String): ReadPost

    @Insert
    fun insertAll(vararg readPosts: ReadPost)

    @Delete
    fun delete(readPost: ReadPost)
}