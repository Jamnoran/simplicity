package com.example.simplicityaclientforreddit.ui.main.models.internal.enums

enum class PostType {
    LINK, IMAGE, IMGUR_LINK, RICH_VIDEO, IS_VIDEO, GALLERY, TOURNAMENT, NONE
}
