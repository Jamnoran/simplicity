package com.example.simplicityaclientforreddit.ui.main.ui.custom

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.bumptech.glide.Glide
import com.example.simplicityaclientforreddit.R
import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.models.internal.enums.PostType
import com.example.simplicityaclientforreddit.ui.main.usecases.GetPostTypeUseCase
import com.squareup.picasso.Picasso


class RedditMedia(val width: Int) {
    private lateinit var postImageView: ImageView
    private lateinit var postWebView: WebView
    private lateinit var postContent: TextView

    private lateinit var postGalleryContent: ConstraintLayout

    private lateinit var postLinkPreview: ImageView

    private lateinit var postLinkSrc: TextView
    private lateinit var postLinkDesc: TextView
    private lateinit var postGalleryCount: TextView

    fun init(post: RedditPost, view: ConstraintLayout) {
        setUpViews(view)

        post.data.let { data->
            // Show if data exists
            when(GetPostTypeUseCase().execute(data)){
                PostType.LINK -> {
                    showLink(data)
                }
                PostType.GALLERY -> {
                    showGallery(data, view.context)
                }
                PostType.IMAGE -> {
                    showImage(data, view.context)
                }
                PostType.IS_VIDEO -> {
                    showVideo(data)
                }
                PostType.RICH_VIDEO -> {
                    showRichVideo(data)
                }
                PostType.TOURNAMENT -> {
                    view.visibility = View.GONE
                }
                PostType.IMGUR_LINK -> {
                    data.urlOverriddenByDest?.let{
//                        sendToBrowser(it)
                        showLink(data)
                    }
                }
            }

            data.selftext?.let{
                postContent.text = it
            }
        }
    }

    private fun setUpViews(view: ConstraintLayout) {
        postImageView = view.findViewById(R.id.reddit_image)
        postWebView = view.findViewById(R.id.reddit_webview)

        postContent = view.findViewById(R.id.reddit_text_content)
        postGalleryContent = view.findViewById(R.id.gallery_layout)

        postLinkPreview = view.findViewById(R.id.reddit_link_preview)
        postLinkSrc = view.findViewById(R.id.reddit_link_src)
        postLinkDesc = view.findViewById(R.id.reddit_link_description)
        postGalleryCount = view.findViewById(R.id.reddit_gallery_count)

        postGalleryContent.visibility = View.GONE

        postImageView.visibility = View.GONE
        postWebView.visibility = View.GONE
        postLinkPreview.visibility = View.GONE
        postLinkSrc.visibility = View.GONE
        postLinkDesc.visibility = View.GONE
        postContent.visibility = View.GONE
        postGalleryCount.visibility = View.GONE
    }

    private fun showGallery(data: RedditPost.Data, context: Context) {
        postGalleryContent.visibility = View.VISIBLE
        postGalleryCount.visibility = View.VISIBLE
        var galleryCountText = "1/${data.mediaMetadata.size}"
        postGalleryCount.text = galleryCountText

        var urlForPicture = getImageInGallery(0, data)
        loadImageOrGif(urlForPicture, context)
        var position = 0
        postGalleryContent.findViewById<View>(R.id.navigate_left).setOnClickListener {
            if(position > 0 ) position--
            urlForPicture = getImageInGallery(position, data)
            Log.i("RedditMedia", "User clicked Left, showing picture on position $position with this image $urlForPicture")
            urlForPicture?.let {
                loadImageOrGif(urlForPicture, context)
                galleryCountText = "${(position + 1)}/${data.mediaMetadata.size}"
                postGalleryCount.text = galleryCountText
            }
        }
        postGalleryContent.findViewById<View>(R.id.navigate_right).setOnClickListener {
            if((position + 1) < data.mediaMetadata.size) position++
            Log.i("RedditMedia", "User clicked Right, showing picture on position $position with this image $urlForPicture")
            urlForPicture = getImageInGallery(position, data)
            urlForPicture?.let {
                loadImageOrGif(urlForPicture, context)
                galleryCountText = "${(position + 1)}/${data.mediaMetadata.size}"
                postGalleryCount.text = galleryCountText
            }
        }
    }

    private fun loadImageOrGif(urlForPicture: String?, context: Context) {
        urlForPicture?.let {
            if(it.contains(".gif")){
                loadGif(it, context)
            }else{
                loadImage(urlForPicture, postImageView)
            }
        }
    }

    private fun showImage(data: RedditPost.Data, context: Context) {
        data.urlOverriddenByDest?.let {
            if(it.contains(".gif")){
                loadGif(it, context)
            }else{
                loadImage(it, postImageView)
            }
        }
    }

    private fun showVideo(data: RedditPost.Data) {
        data.media?.oembed?.let {
            showWebView(postWebView, it.provider_url)
            Log.i("RedditMedia", "Showing oembed with url ${it.provider_url}")
        }
        data.media?.reddit_video?.let {
            playMediaWithSound(postWebView, it.fallback_url, it.height)
        }
        data.preview?.reddit_video_preview?.let {
            showWebView(postWebView, it.fallback_url)
            Log.i("RedditMedia", "Showing reddit_video_preview with url ${it.fallback_url}")
        }
    }

    private fun showRichVideo(data: RedditPost.Data) {
        if(data.secureMediaEmbed != null){
            data.secureMediaEmbed?.media_domain_url?.let { mediaUrl->
                showWebView(postWebView, mediaUrl)
            }
        }else{
            Log.i("RedditMedia","rich:video was not of type secure_media_embed id: ${data.id}")
        }
    }

    private fun showLink(data: RedditPost.Data) {
        postLinkDesc.visibility = View.VISIBLE
        postLinkSrc.visibility = View.VISIBLE

        data.title?.let{postLinkDesc.text = it}
        data.domain?.let{postLinkSrc.text = it}

        data.thumbnail?.let {
            postLinkPreview.visibility = View.VISIBLE
            val picasso = Picasso.get()
            picasso.load(it)
                .into(postLinkPreview)

            Log.i("RedditMedia", "Found image with urlOverriddenByDest $it")
        }
    }


    private fun loadGif(it: String, context: Context) {
        postImageView.visibility = View.VISIBLE
        Glide
            .with(context) // replace with 'this' if it's in activity
            .load(it)
            .error(R.drawable.error_download) // show error drawable if the image is not a gif
            .into(postImageView)
    }

    private fun playMediaWithSound(postWebView: WebView, fallbackUrl: String, height: Int?) {
        showWebView(postWebView, fallbackUrl, height)
        val audioUrl = fallbackUrl.replace("/DASH_", "/audio_")
        // https://v.redd.it/94zu4y0wf2f71/DASH_360.mp4?source=fallback  ¤ replace _360 with audio (this can be any resolution so number between _ and .)
        Log.i("RedditMedia", "Showing reddit_video with url $fallbackUrl and audio url $audioUrl")
    }

    private fun showWebView(postWebView: WebView, url: String) {
        showWebView(postWebView, url, null)
    }

    private fun showWebView(postWebView: WebView, url: String, height: Int?) {
        postWebView.visibility = View.VISIBLE
        postWebView.loadUrl(url)

        val webSettings = postWebView.settings
        webSettings.javaScriptEnabled = true

        postWebView.webViewClient = WebClientClass()
        Log.i("RedditMedia", "Showing this url : $url")
        height?.let{
            val params = ConstraintLayout.LayoutParams(0, height)
            postWebView.layoutParams = params
        }
        postWebView.loadUrl(url)
    }

    private fun getFirstImageInGallery(redditData: RedditPost.Data): String {
        for(galleryData in redditData.mediaMetadata){
            return getConvertedImageUrl(galleryData.value.s.u)
        }
        return ""
    }

    private fun getImageInGallery(position: Int, redditData: RedditPost.Data): String? {
        if(position<0) return null
        if(position-1 > redditData.mediaMetadata.size) return null

        var i = 0
        for(galleryData in redditData.mediaMetadata){
            if(i == position){
                return getConvertedImageUrl(galleryData.value.s.u)
            }
            i++
        }
        return null
    }

    private fun getConvertedImageUrl(s: String): String {
        return s.replace("&amp;", "&")
    }

    private fun loadImage(it: String, view: ImageView) {
        view.visibility = View.VISIBLE
//        try {
//            Picasso.get().load(it)
//                .resize( view.width, 0)
//                .into(view)
//        } catch (e: Exception) {
//            Log.e("RedditMedia", "Failed showing this image: $it", e)
//        }
        val picasso = Picasso.get()
        if (width > 0) {
            picasso
                .load(it)
                .resize(width, 0)
                .into(view)
        } else {
            picasso
                .load(it)
                .resize(800, 0)
                .into(view)
        }
    }
}