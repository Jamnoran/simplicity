package com.example.simplicityaclientforreddit.ui.main.usecases

import com.example.simplicityaclientforreddit.ui.main.SessionDatabase
import com.example.simplicityaclientforreddit.ui.main.models.internal.Session


class CombineSessionUseCase {
    fun combineSessions() {
        val db = SessionDatabase()
        val sessions = db.getSessions()
        sessions[0] = combineSessions(sessions[0], sessions[1])
        sessions.removeAt(1)
        db.updateSessions(sessions)
    }

    private fun combineSessions(currentSession: Session, usersLastSession: Session): Session {
        return Session(
            usersLastSession.id,
            currentSession.firstId?: usersLastSession.firstId,
            currentSession.lastReadId,
            usersLastSession.nextId,
            usersLastSession.count + currentSession.count,
            null
        )
    }
}