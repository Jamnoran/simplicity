package com.example.simplicityaclientforreddit.ui.main.models.external

data class TournamentData(var status: String?) {
}
