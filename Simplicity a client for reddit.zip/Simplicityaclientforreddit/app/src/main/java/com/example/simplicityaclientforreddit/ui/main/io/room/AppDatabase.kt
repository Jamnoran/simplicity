package com.example.simplicityaclientforreddit.ui.main.io.room

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.simplicityaclientforreddit.ui.main.models.internal.ReadPost

@Database(entities = [ReadPost::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun readPostDao(): ReadPostDao
}