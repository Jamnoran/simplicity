package com.example.simplicityaclientforreddit.ui.main.usecases

import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost
import com.example.simplicityaclientforreddit.ui.main.models.internal.enums.PostType


class GetPostTypeUseCase {
    fun execute(data: RedditPost.Data): PostType {
        if (data.is_video) {
            return PostType.IS_VIDEO
        }
        if(data.postHint == "link" && containsImgur(data)){
            return PostType.IMGUR_LINK
        }

        if (data.is_gallery) {
            return PostType.GALLERY
        }
        if(data.tournament_data != null){
            return PostType.TOURNAMENT
        }

        // Specific postHint types
        return when (data.postHint) {
            "link" -> {
                PostType.LINK
            }
            "rich:video" -> {
                PostType.RICH_VIDEO
            }
            "image" -> {
                PostType.IMAGE
            }
            else -> {
                PostType.NONE
            }
        }
    }

    private fun containsImgur(data: RedditPost.Data): Boolean {
        if(data.url != null && data.url!!.contains("imgur.com")){
            return true
        }
        return false
    }
}