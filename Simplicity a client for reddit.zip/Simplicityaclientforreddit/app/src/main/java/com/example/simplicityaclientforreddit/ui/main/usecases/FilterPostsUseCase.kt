package com.example.simplicityaclientforreddit.ui.main.usecases

import com.example.simplicityaclientforreddit.ui.main.models.external.RedditPost

class FilterPostsUseCase {
    fun canAdd(redditPost: RedditPost): Boolean{
        val usersLastSession = GetNextSessionUseCase().getNextSession()
        if(usersLastSession == null){
            return true
        }else if(redditPost.data.id.equals(usersLastSession.firstId)){
            CombineSessionUseCase().combineSessions()
            return false
        }
        return true

//        // Old
//        val nextSession = GetNextSessionUseCase().getNextSession()
//        if(nextSession == null || redditPost.data.id.equals(nextSession.firstId)){
//           return false
//        }
//        return true
    }
}